const fs = require('fs').promises;
const path = require('path');

const TMP_DIR = path.join(__dirname, '..', 'tmp', 'cam');
const FRAME_PATH = path.join(TMP_DIR, 'latest.jpg');
const DETECTIONS_PATH = path.join(TMP_DIR, 'detections.json');

// Создаём папку при старте
fs.mkdir(TMP_DIR, { recursive: true }).catch(() => {});

// 🔹 POST /api/cam/upload
exports.receiveFrame = async (req, res) => {
  try {
    await fs.writeFile(FRAME_PATH, req.body);
    res.sendStatus(200);
  } catch (err) {
    console.error('❌ Ошибка сохранения кадра:', err);
    res.status(500).json({ error: 'Save failed' });
  }
};

// 🔹 POST /api/cam/detections
exports.receiveDetections = async (req, res) => {
  try {
    await fs.writeFile(DETECTIONS_PATH, JSON.stringify(req.body));
    res.sendStatus(200);
  } catch (err) {
    console.error('Ошибка сохранения детектов:', err);
    res.status(500).json({ error: 'Save failed' });
  }
};

// 🔹 GET /api/cam/frame
exports.serveFrame = async (req, res) => {
  try {
    await fs.access(FRAME_PATH); // Проверка существования
    res.sendFile(FRAME_PATH);
  } catch {
    res.status(404).send('No frame yet');
  }
};

// 🔹 GET /api/cam/detections
exports.getDetections = async (req, res) => {
  try {
    const data = await fs.readFile(DETECTIONS_PATH, 'utf8');
    res.json(JSON.parse(data));
  } catch {
    res.json([]);
  }
};
