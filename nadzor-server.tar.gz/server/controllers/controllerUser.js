const jwt = require('jsonwebtoken');
const modelUser = require('../models/modelUser');

const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-prod-please';
const COOKIE_OPTIONS = {
  httpOnly: true,          // JS не видит куку (защита от XSS)
  secure: true,            // Обязательно true, если сайт на HTTPS
  sameSite: 'lax',         // 'lax' надёжнее 'strict' при редиректах/обновлении
  maxAge: 7 * 24 * 60 * 60 * 1000, // 7 дней
  path: '/'                // Кука доступна на всех путях домена
};

// Регистрация
exports.register = async (req, res) => {
  try {
    const { user, password, nickname } = req.body; // user = login
    if (!user || !password) return res.status(400).json({ error: 'Login and password required' });

    const existing = await modelUser.findByLogin(user);
    if (existing) return res.status(409).json({ error: 'User already exists' });

    const newUser = await modelUser.create(user, nickname || user, password, 2); // privilege=2 по умолчанию
    
    const token = jwt.sign({ userId: newUser.id, login: newUser.login }, JWT_SECRET, { expiresIn: '7d' });
    res.cookie('token', token, COOKIE_OPTIONS);
    
    res.status(201).json({ user: { id: newUser.id, login: newUser.login, nickname: newUser.nickname } });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
};

// Логин
exports.login = async (req, res) => {
  try {
    const { user, password } = req.body; // user = login
    if (!user || !password) return res.status(400).json({ error: 'Login and password required' });

    const foundUser = await modelUser.findByLogin(user);
    if (!foundUser) return res.status(401).json({ error: 'Invalid credentials' });

    const valid = await modelUser.verifyPassword(foundUser, password);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    // Обновим last_online
    await modelUser.updateLastOnline(foundUser.id);

    const token = jwt.sign({ userId: foundUser.id, login: foundUser.login }, JWT_SECRET, { expiresIn: '7d' });
    res.cookie('token', token, COOKIE_OPTIONS);
    
    res.json({ user: { id: foundUser.id, login: foundUser.login, nickname: foundUser.nickname, privilege: foundUser.privilege } });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
};

// Выход
exports.logout = (req, res) => {
  res.clearCookie('token', COOKIE_OPTIONS);
  res.json({ message: 'Logged out' });
};

// Проверка сессии (для авто-логина)
exports.me = async (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
  res.json({ user: req.user });
};
