const express = require('express');
const router = express.Router();
const camController = require('../controllers/camController');
const authMiddleware = require('../middleware/authMiddleware');
const requirePrivilege = require('../middleware/requirePrivilege');
const cookieParser = require('cookie-parser');

// Парсер куки
router.use(cookieParser());

// 🔐 Защита: только авторизованные + только admin
router.use(authMiddleware);
router.use(requirePrivilege('admin'));

// 📥 От ESP32 и Python
router.post('/upload', express.raw({ type: 'image/jpeg', limit: '2mb' }), camController.receiveFrame);
router.post('/detections', express.json(), camController.receiveDetections);

// 📤 Для React
router.get('/frame', camController.serveFrame);
router.get('/detections', camController.getDetections);

module.exports = router;
