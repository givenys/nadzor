const db = require('./../configs/database.js');
const bcrypt = require('bcrypt');

module.exports = {
  // Найти пользователя по login
  async findByLogin(login) {
    return new Promise((resolve, reject) => {
      db.query('SELECT id, login, nickname, password_hash, privilege FROM users WHERE login = ?', [login], (err, results) => {
        if (err) return reject(err);
        resolve(results[0] || null);
      });
    });
  },

  // Создать нового пользователя
  async create(login, nickname, password, privilege = 2) {
    const hashedPassword = await bcrypt.hash(password, 10);
    return new Promise((resolve, reject) => {
      db.query(
        'INSERT INTO users (login, nickname, password_hash, privilege) VALUES (?, ?, ?, ?)',
        [login, nickname, hashedPassword, privilege],
        (err, results) => {
          if (err) return reject(err);
          resolve({ id: results.insertId, login, nickname, privilege });
        }
      );
    });
  },

  // Проверить пароль
  async verifyPassword(user, password) {
    return bcrypt.compare(password, user.password_hash);
  },

  // Обновить last_online
  async updateLastOnline(userId) {
    return new Promise((resolve, reject) => {
      db.query('UPDATE users SET last_online = NOW() WHERE id = ?', [userId], (err) => {
        if (err) return reject(err);
        resolve();
      });
    });
  }
};


