const jwt = require('jsonwebtoken');
const modelUser = require('../models/modelUser');

const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-prod-please';

module.exports = async (req, res, next) => {
  const token = req.cookies?.token;
  if (!token) return res.status(401).json({ error: 'No token' });

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = await modelUser.findByLogin(payload.login);
    if (!user) return res.status(401).json({ error: 'User not found' });

    // Добавляем пользователя в запрос (без password_hash!)
    req.user = { 
      id: user.id, 
      login: user.login, 
      nickname: user.nickname,
      privilege: user.privilege 
    };
    next();
  } catch (err) {
    console.error('Auth middleware error:', err);
    res.clearCookie('token');
    res.status(401).json({ error: 'Invalid token' });
  }
};
