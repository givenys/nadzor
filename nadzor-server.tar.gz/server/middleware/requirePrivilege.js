// Проверяет, есть ли у пользователя нужная привилегия
// usage: requirePrivilege('admin')(req, res, next)
module.exports = (requiredTitle) => {
  return async (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Not authenticated' });

    try {
      const db = require('../configs/database');
      
      // Получаем название привилегии из БД
      const [rows] = await db.promise().query(
        'SELECT p.title FROM privileges p JOIN users u ON u.privilege = p.id WHERE u.id = ?',
        [req.user.id]
      );
      
      const userPrivilege = rows[0]?.title;
      
      if (!userPrivilege || userPrivilege !== requiredTitle) {
        return res.status(403).json({ error: `Access denied: ${requiredTitle} required` });
      }
      
      next();
    } catch (err) {
      console.error('Privilege check error:', err);
      res.status(500).json({ error: 'Privilege check failed' });
    }
  };
};
