const mysql = require("mysql2");

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT,

    waitForConnections: true,
    connectionLimit: 10
})

pool.checkConnection = (callback) => {
  pool.query('SELECT 1 + 1 AS solution', (err, result) => {
    if (err) {
      console.error('DB connection error:', err.message);
      if (callback) callback(err);
      return;
    }
    console.log('DB connected, solution:', result[0].solution);
    if (callback) callback(null, result);
  });
};

module.exports = pool;
